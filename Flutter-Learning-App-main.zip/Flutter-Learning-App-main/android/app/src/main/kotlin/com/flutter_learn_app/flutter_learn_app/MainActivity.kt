package com.flutter_learn_app.flutter_learn_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
